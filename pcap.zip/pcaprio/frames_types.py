
import binascii
from dataclasses import dataclass
from .enumerations import PackageType


class PCAPFrame:
    destination_mac: str
    source_mac: str
    
    package_type: PackageType = None

    def __init__(self, destination_mac: str, source_mac: str, package_type: PackageType = None) -> None:
        self.destination_mac = destination_mac
        self.source_mac = source_mac
        self.package_type = package_type
    
    def __repr__(self) -> str:
        return f'<PCAPPacketParsedView: {self.destination_mac} -> {self.source_mac} ({self.package_type})>'


@dataclass
class Ethernet2Frame(PCAPFrame):
    destination_mac: str
    source_mac: str
    ethertype: str
    data: bytes

    package_type: PackageType = PackageType.Ethernet2
    
    @property
    def hexlify_data(self) -> str:
        return binascii.hexlify(self.data).decode('utf-8')


def identify_frame(raw_data: bytes) -> PCAPFrame:
    """
    Короче, это было на преднашке, страница 14 (преднашка 3_2022_Ethernet_linkova 20)
    """

    if int.from_bytes(raw_data[12:14], 'big') >= 1500:
        return Ethernet2Frame(
            destination_mac=raw_data[0:6].hex(':'),
            source_mac=raw_data[6:12].hex(':'),
            ethertype=raw_data[12:14].hex(':'),
            data=raw_data[14:]
        )
    elif int.from_bytes(raw_data[12:14], 'big') < 1500:
        if raw_data[14:16].hex() == "AAAA":
            return PCAPFrame(
                destination_mac=raw_data[0:6].hex(':'),
                source_mac=raw_data[6:12].hex(':'),
                package_type=PackageType.IEEE_802_3_LLC_SNAP
            )
        elif raw_data[14:16].hex() == "FFFF":
            return PCAPFrame(
                destination_mac=raw_data[0:6].hex(':'),
                source_mac=raw_data[6:12].hex(':'),
                package_type=PackageType.Novell_802_3_Raw
            )
        else:
            return PCAPFrame(
                destination_mac=raw_data[0:6].hex(':'),
                source_mac=raw_data[6:12].hex(':'),
                package_type=PackageType.IEEE_802_3_LLC
            )