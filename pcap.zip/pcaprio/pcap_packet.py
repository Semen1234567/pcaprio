import binascii


from dataclasses import dataclass, field
from .frames_types import Ethernet2Frame, identify_frame
from .frames_types import PCAPFrame
from .enumerations import EtherTypes



@dataclass
class PCAPPacket:
    timestamp1: int
    timestamp2: int
    incl_len: int
    orig_len: int
    data: bytes
    

    raw: bytes = field(repr=False, default=None)
    frame: PCAPFrame = field(default=None)

    @property
    def hexlify_data(self) -> str:
        return binascii.hexlify(self.data).decode('utf-8')
    

    def parse(self) -> None:
        self.frame = identify_frame(self.data).package_type
        # iseth = self._parse_packet_like_ethernet()
        # if iseth:
        #     self.frame = iseth
        # else:
        #     self.frame = self._parse_default()
    
    def _parse_default(self) -> None:
        destination_mac = self.hexlify_data[0:12]
        source_mac = self.hexlify_data[12:24]
        
        destination_mac = ':'.join(destination_mac[i:i+2] for i in range(0, len(destination_mac), 2))
        source_mac = ':'.join(source_mac[i:i+2] for i in range(0, len(source_mac), 2))

        return PCAPFrame(
            destination_mac=destination_mac,
            source_mac=source_mac
        )
    
    def _parse_packet_like_ethernet(self) -> Ethernet2Frame | None:
        destination_mac = self.hexlify_data[0:12]
        source_mac = self.hexlify_data[12:24]
        ethertype = self.hexlify_data[24:28]

        if ethertype not in EtherTypes:
            return False
        
        ethertype_name = EtherTypes[ethertype]

        data = self.data[14:]

        destination_mac = ':'.join(destination_mac[i:i+2] for i in range(0, len(destination_mac), 2))
        source_mac = ':'.join(source_mac[i:i+2] for i in range(0, len(source_mac), 2))
        
        return Ethernet2Frame(
            destination_mac=destination_mac,
            source_mac=source_mac,
            ethertype=ethertype_name,
            data=data
        )
